import os
from setuptools import setup
 
README = open(os.path.join(os.path.dirname(__file__), 'README.rst')).read()
 
# Allow setup.py to be run from any path
os.chdir(os.path.normpath(os.path.join(os.path.abspath(__file__), os.pardir)))
 
setup(
    name = 'django-scalefast-stories',
    version = '0.1',
    packages = ['scalefast'],
    include_package_data = True,
    license = 'BSD License',
    description = 'A blog like django app',
    long_description = README,
    url = 'http://www.awesomeurl.com/',
    author = 'Eduardo Rojas',
    author_email = 'eduardo.rojas@scalefast.com',
    classifiers =[
        'Environment :: Web Environment',
        'Framework :: Django',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License', # example license
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3.6.2',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Internet :: WWW/HTTP :: Dynamic Content'
    ]
)
