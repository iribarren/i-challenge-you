=====
Scalefast Stories
=====

Blog-like app to write some cool stories about daily life at Scalefast.

Quick start
-----------

1. Add "scalefast_stories" to INSTALLED_APPS:
  INSTALLED_APPS = {
    ...
    'scalefast_stories'
  }

2. Include the myblog URLconf in urls.py:
  url(r'^scalefast_stories/', include('scalefast_stories.urls'))


