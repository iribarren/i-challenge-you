from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from django.shortcuts import get_object_or_404, render

# Create your views here.
#from .models import Asset


def index(request):
    #latest_asset_list = Asset.objects.order_by('-identifier')[:5]
    template = loader.get_template('scalefast_stories/example.html')
    context = {
        #'latest_asset_list': latest_asset_list,
	'movida': 'movidote de lo maximo'
    }

    return HttpResponse(template.render(context, request))

'''def detail(request, asset_id):
    try:
        asset = Asset.objects.get(pk=asset_id)
    except Asset.DoesNotExist:
        raise Http404("Asset does not exist")
    return render(request, 'simple_inventory/templates/example.html', {'asset': asset})'''

