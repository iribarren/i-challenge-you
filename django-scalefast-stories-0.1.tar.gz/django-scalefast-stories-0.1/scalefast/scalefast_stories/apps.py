from django.apps import AppConfig


class ScalefastStoriesConfig(AppConfig):
    name = 'scalefast_stories'
